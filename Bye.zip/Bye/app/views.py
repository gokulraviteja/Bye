from django.shortcuts import render

# Create your views here.


def cat(request):
    return render(request,"cat/cat.html")

def staticcat(request):
    return render(request,"cat/staticcat.html")

def bye(request):
    return render(request,"bye/bye.html")