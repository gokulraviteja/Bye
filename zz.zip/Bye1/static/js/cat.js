


window.onload = function() {

    setTimeout(function (){
        document.getElementById("redirect-timer").innerText = "2"
    },1000)

    setTimeout(function (){
        document.getElementById("redirect-timer").innerText = "1"
    },2000)

    setTimeout(function (){
        window.location.href = "/bye";
    },3000)

};