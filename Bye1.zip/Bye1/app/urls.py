




from django.urls import path
from . import views


urlpatterns = [

    path('',views.cat),
    path('cat',views.staticcat),
    path('bye',views.bye),

]